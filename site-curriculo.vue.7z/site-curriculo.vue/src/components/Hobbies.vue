<template>
  <section id="hobbies">
    <h2>Hobbies</h2>
    <div class="hobbies-grid">
      <div class="hobby-card">🎧 <span>Ouvir músicas</span></div>
      <div class="hobby-card">🤝 <span>Eventos sociais</span></div>
      <div class="hobby-card">📘 <span>Ler sobre Psicologia</span></div>
      <div class="hobby-card">🗂️ <span>Organizar ambientes</span></div>
      <div class="hobby-card">👨‍👩‍👧 <span>Lazer com a família</span></div>
      <div class="hobby-card">✈️ <span>Viajar pelo Brasil e exterior</span></div>
    </div>
  </section>
</template>
