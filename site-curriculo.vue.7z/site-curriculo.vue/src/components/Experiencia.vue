<template>
  <section id="experiencia">
    <h2>Experiência</h2>
    <p>
      Experiência prática em atendimento ao público, organização de eventos...
    </p>
  </section>
</template>
