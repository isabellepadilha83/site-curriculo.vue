<template>
  <header>
    <div class="header-content">
      <img src="/isabelle.jpg" alt="Foto profissional de Isabelle Padilha" class="profile-img" />
      <h1>Isabelle de Oliveira Padilha</h1>
      <p>Futura estudante de Psicologia | Interesse em Administração e Desenvolvimento Humano</p>
    </div>
  </header>
</template>
