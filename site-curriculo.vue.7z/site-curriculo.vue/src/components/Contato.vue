<template>
  <section id="contato">
    <h2>Contato</h2>
    <p>Email: <a href="mailto:isabelle.o.padilha@gmail.com">isabelle.o.padilha@gmail.com</a></p>
    <p>Telefone: (19) 99950-8640</p>
    <p>LinkedIn: 
      <a href="https://www.linkedin.com/in/isabelle-de-oliveira-padilha-9833a92b8/" target="_blank">
        linkedin.com/in/isabelle-de-oliveira-padilha
      </a>
    </p>
    <a class="btn-download" href="/Currículo- Isabelle Padilha.pdf" download>📄 Baixar Currículo</a>
  </section>
</template>
