<template>
  <section id="formacao">
    <h2>Formação Acadêmica</h2>
    <ul>
      <li>Psicologia – Início em Janeiro de 2026</li>
      <li>Curso de Auxiliar Administrativo – SENAI (início em nov/2025)</li>
      <li>Curso Técnico em Desenvolvimento de Sistemas – SENAI - 2 anos</li>
      <li>Inglês Intermediário – Em busca de certificação</li>
      <li>Curso de Liderança – Concluído</li>
      <li>Curso em Gestão de Pessoas – Concluído</li>
      <li>Curso de LGPD – Concluído</li>
      <li>Curso de Segurança no Trabalho – Concluído</li>
      <li>Curso Economia Circular – Concluído</li>
    </ul>
  </section>
</template>
