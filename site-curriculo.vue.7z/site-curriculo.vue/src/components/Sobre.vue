<template>
  <section id="sobre">
    <h2>Sobre Mim</h2>
    <p>
      Sou uma jovem dedicada, comunicativa e apaixonada por pessoas...
    </p>
  </section>
</template>
